Nextflow 生物資訊工作流程講義：分享套件

1. 先將整個 ZIP 解壓縮，再用 Chrome 或 Edge 開啟 index.html。
2. 正文、流程圖、MultiQC 圖表與已保存的 Seqera AI 最終摘要均已內嵌。
   閱讀不需安裝 Nextflow、Docker，不需 token，也不會重新呼叫 AI。
3. 要執行練習，請依講義安裝工具，進入 demos/nextflow-qc 後執行指令。
   安裝、下載容器、AI 呼叫與 Gmail 寄信仍需網路及自己的核准憑證。
4. demos/ 含程式、設定與合成 FASTQ；lessons/ 含 Markdown 原稿。
   請保留解壓後目錄結構，才能使用 index.html 的程式及測試檔連結。
5. 本套件不含 token、Nextflow secrets store、.env、work/、.nextflow/、
   主機套件或暫存執行目錄。Gmail 通知未啟用，也未驗證實際送達。
6. QC 與 AI 摘要來自微型人工合成資料，不是臨床分析或檢驗認證。
7. 只需閱讀時，可單獨傳送 index.html；其他教材與程式連結則需要本套件。
8. SHA256SUMS.txt 可用於確認套件內容完整；BUILD-INFO.json 記錄來源雜湊。
   內嵌報告已替換個人路徑，只保留 AI 最終文字，並禁止 API 連線。
